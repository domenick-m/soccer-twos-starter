"""
Lightweight PyTorch-only agent for Soccer Twos.

Reconstructs the RLlib PPO FullyConnectedNetwork architecture and loads
pre-extracted weights — no Ray or RLlib needed at inference time.

Architecture (from RLlib defaults):
  obs (336) -> FC(256, tanh) -> FC(256, tanh) -> logits (9)
  Action space: MultiDiscrete([3, 3, 3])  →  9 total logit outputs
"""

import os
from typing import Dict

import numpy as np
import torch
import torch.nn as nn

from soccer_twos import AgentInterface


class PPOPolicyNet(nn.Module):
    """
    Mirrors the RLlib FullyConnectedNetwork policy (actor) head.
    """

    def __init__(self, obs_size: int = 336, hidden_size: int = 256, logit_size: int = 9):
        super().__init__()
        self.hidden0 = nn.Linear(obs_size, hidden_size)
        self.hidden1 = nn.Linear(hidden_size, hidden_size)
        self.logits = nn.Linear(hidden_size, logit_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.tanh(self.hidden0(x))
        x = torch.tanh(self.hidden1(x))
        return self.logits(x)


class RayAgent(AgentInterface):
    """
    Self-contained PPO agent that loads pre-extracted PyTorch weights.
    No Ray/RLlib initialization required.
    """

    # MultiDiscrete([3, 3, 3]) — each sub-action has 3 choices
    ACTION_DIMS = [3, 3, 3]

    def __init__(self, env):
        super().__init__()
        self.device = torch.device("cpu")

        # Build the policy network
        self.model = PPOPolicyNet(obs_size=336, hidden_size=256, logit_size=9)

        # Load pre-extracted weights
        agent_dir = os.path.dirname(os.path.abspath(__file__))
        weights_path = os.path.join(agent_dir, "model_weights.pt")
        raw_state = torch.load(weights_path, map_location="cpu")

        # Map RLlib weight names to our model's parameter names
        mapping = {
            "_hidden_layers.0._model.0.weight": "hidden0.weight",
            "_hidden_layers.0._model.0.bias": "hidden0.bias",
            "_hidden_layers.1._model.0.weight": "hidden1.weight",
            "_hidden_layers.1._model.0.bias": "hidden1.bias",
            "_logits._model.0.weight": "logits.weight",
            "_logits._model.0.bias": "logits.bias",
        }

        state_dict = {}
        for rllib_name, our_name in mapping.items():
            state_dict[our_name] = raw_state[rllib_name]

        self.model.load_state_dict(state_dict)
        self.model.eval()

    @torch.no_grad()
    def act(self, observation: Dict[int, np.ndarray]) -> Dict[int, np.ndarray]:
        """
        Given observations for each player, return actions as MultiDiscrete arrays.
        Uses greedy argmax over each action dimension's logits.
        """
        actions = {}
        for player_id, obs in observation.items():
            obs_tensor = torch.from_numpy(obs).float().unsqueeze(0).to(self.device)
            logits = self.model(obs_tensor).squeeze(0)

            # Split logits into sub-actions and take argmax for each
            action_parts = []
            offset = 0
            for dim in self.ACTION_DIMS:
                sub_logits = logits[offset : offset + dim]
                action_parts.append(sub_logits.argmax().item())
                offset += dim

            actions[player_id] = np.array(action_parts)
        return actions
